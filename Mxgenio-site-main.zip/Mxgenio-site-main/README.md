# MixGênio

Site que permite transformar músicas com IA (simulada por enquanto). Feito com React + Tailwind.

## Como rodar o projeto

```bash
npm install
npm run dev
```

## Como publicar

- **Vercel:** Conecte este projeto no GitHub e importe pelo site
- **Netlify:** Faça o upload da pasta ou conecte o repositório
- **Replit:** Importe os arquivos e clique em "Run"
