import React from "react";
import MusicTransformer from "./components/MusicTransformer";

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-900 text-white flex items-center justify-center">
      <MusicTransformer />
    </div>
  );
}
