import React, { useState } from "react";

export default function MusicTransformer() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleUpload = (e) => {
    const uploadedFile = e.target.files[0];
    setFile(uploadedFile);
    setResult(null);
  };

  const handleTransform = async () => {
    if (!file) return alert("Envie uma música primeiro");
    setLoading(true);

    // Simulação de IA
    setTimeout(() => {
      setResult("https://example.com/musica-transformada.mp3");
      setLoading(false);
    }, 3000);
  };

  return (
    <div className="bg-zinc-800 p-6 rounded-xl shadow-xl max-w-md w-full">
      <h1 className="text-2xl font-bold mb-4">🎵 MixGênio</h1>
      <input type="file" accept="audio/*" onChange={handleUpload} className="mb-4" />
      <button
        onClick={handleTransform}
        className="bg-blue-500 px-4 py-2 rounded hover:bg-blue-600"
        disabled={loading}
      >
        {loading ? "Transformando..." : "Transformar com IA"}
      </button>
      {result && (
        <div className="mt-4">
          <p className="mb-2">✅ Música transformada com sucesso!</p>
          <a href={result} className="text-blue-300 underline" target="_blank" rel="noreferrer">
            Baixar música
          </a>
        </div>
      )}
    </div>
  );
}
